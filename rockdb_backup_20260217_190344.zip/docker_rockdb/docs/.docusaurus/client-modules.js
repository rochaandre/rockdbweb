export default [
  require("/opt/docusaurus/.docusaurus/docusaurus-plugin-css-cascade-layers/default/layers.css"),
  require("/opt/docusaurus/node_modules/infima/dist/css/default/default.css"),
  require("/opt/docusaurus/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/opt/docusaurus/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/opt/docusaurus/src/css/custom.css"),
];
