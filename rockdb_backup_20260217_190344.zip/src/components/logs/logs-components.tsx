export function LogViewer({ logs }: { logs: any[] }) {
    return (
        <div className="flex-1 overflow-auto bg-black text-white font-mono text-xs p-4 rounded-md">
            {logs.length === 0 ? "No alert logs found." : logs.map((l, i) => (
                <div key={i} className="mb-1">{l.timestamp} - {l.message}</div>
            ))}
        </div>
    )
}

export function OutstandingAlertsTable({ alerts }: { alerts: any[] }) {
    return (
        <div className="border border-border rounded-md overflow-hidden">
            <table className="w-full text-sm">
                <thead className="bg-muted text-muted-foreground font-medium">
                    <tr>
                        <th className="p-2 text-left">Level</th>
                        <th className="p-2 text-left">Message</th>
                        <th className="p-2 text-left">Time</th>
                    </tr>
                </thead>
                <tbody>
                    {alerts.length === 0 ? (
                        <tr><td colSpan={3} className="p-4 text-center text-muted-foreground">No outstanding alerts.</td></tr>
                    ) : alerts.map((a, i) => (
                        <tr key={i} className="border-t">
                            <td className="p-2">{a.level}</td>
                            <td className="p-2">{a.message}</td>
                            <td className="p-2">{a.timestamp}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}
