-- New Script
SELECT 'Hello' FROM dual;