docker-compose build rockdb-app  
docker-compose down && docker-compose up -d

