#!/bin/bash
set -e

# This script can be used to perform additional initialization
# InfluxDB 2.x auto-setup is already handled by environment variables in docker-compose.yml
# (DOCKER_INFLUXDB_INIT_MODE=setup)

echo "InfluxDB initialization script running..."

# Example: Create additional buckets if needed
# influx bucket create -n supplementary_bucket -o rockdb -r 30d -t $DOCKER_INFLUXDB_INIT_ADMIN_TOKEN

echo "InfluxDB initialization complete."
