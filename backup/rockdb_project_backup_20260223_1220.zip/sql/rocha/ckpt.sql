@save_sqlplus_settings


set feedback off
@fulldate
set feedback 5
@log
@dirty_cache
@log_file_usage2

@restore_sqlplus_settings
