select status, to_char(sysdate,'DD/MM/YYYY HH24:MI') data, sysdate data2 from v$Instance ;
