alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';


